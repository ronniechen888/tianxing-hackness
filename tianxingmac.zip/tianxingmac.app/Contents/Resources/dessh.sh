mkdir -p $2
cp -r -f $1 $3
cp -r -f $4 $5
cp -r -f $6 $7