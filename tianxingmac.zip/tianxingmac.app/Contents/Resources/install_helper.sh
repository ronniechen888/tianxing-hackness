#!/bin/sh

#  install_helper.sh
#  shadowsocks
#
#  Created by clowwindy on 14-3-15.

cd `dirname "${BASH_SOURCE[0]}"`
sudo mkdir -p "/Library/Application Support/TX_Connect1/"
sudo cp shadowsocks_sysconf "/Library/Application Support/TX_Connect1/"
sudo chown root:admin "/Library/Application Support/TX_Connect1/shadowsocks_sysconf"
sudo chmod +s "/Library/Application Support/TX_Connect1/shadowsocks_sysconf"

echo done
