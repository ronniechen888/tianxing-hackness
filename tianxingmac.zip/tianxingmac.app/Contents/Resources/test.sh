echo "abc"
cd $6
./$7 create --l2tp $1 --endpoint $4 --username $2 --password $3 --shared-secret $5 > app.log 2>&1