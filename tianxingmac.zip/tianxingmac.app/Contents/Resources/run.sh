./ip-down
./ip-up
echo "finished"	